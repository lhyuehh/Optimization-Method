# Optimization-Method
Record Every Assignment
